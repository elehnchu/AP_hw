#ifndef ITERATIVE_H_
#define ITERATIVE_H_

int gcd_iterative(int m, int n);


#endif
