#ifndef RECURSIVE_H_
#define RECURSIVE_H_

int gcd_recursive(int m, int n);


#endif 
